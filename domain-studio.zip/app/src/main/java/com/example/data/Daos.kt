package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUserById(id: String)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 200")
    fun getRecentLogs(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLog)

    @Query("DELETE FROM audit_logs")
    suspend fun clearLogs()
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY lastUpdated DESC")
    fun getAllProjectsFlow(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: String): Project?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project)

    @Update
    suspend fun updateProject(project: Project)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)
}

@Dao
interface DomainListDao {
    @Query("SELECT * FROM domain_lists WHERE projectId = :projectId ORDER BY createdAt DESC")
    fun getListsForProject(projectId: String): Flow<List<DomainList>>

    @Query("SELECT * FROM domain_lists WHERE id = :id LIMIT 1")
    suspend fun getListById(id: String): DomainList?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertList(list: DomainList)

    @Query("DELETE FROM domain_lists WHERE id = :id")
    suspend fun deleteListById(id: String)
}

@Dao
interface DomainDao {
    @Query("""
        SELECT * FROM domains 
        WHERE projectId = :projectId 
        AND (:listId IS NULL OR listId = :listId)
        AND (:search IS NULL OR domainName LIKE :search)
        AND (:tld IS NULL OR tld = :tld)
        AND (:minScore IS NULL OR totalScore >= :minScore)
        AND (:premiumOnly = 0 OR isPremium = 1)
        ORDER BY totalScore DESC 
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getFilteredDomains(
        projectId: String,
        listId: String?,
        search: String?,
        tld: String?,
        minScore: Float?,
        premiumOnly: Int,
        limit: Int,
        offset: Int
    ): List<DomainEntity>

    @Query("""
        SELECT COUNT(*) FROM domains 
        WHERE projectId = :projectId 
        AND (:listId IS NULL OR listId = :listId)
        AND (:search IS NULL OR domainName LIKE :search)
        AND (:tld IS NULL OR tld = :tld)
        AND (:minScore IS NULL OR totalScore >= :minScore)
        AND (:premiumOnly = 0 OR isPremium = 1)
    """)
    suspend fun getFilteredDomainsCount(
        projectId: String,
        listId: String?,
        search: String?,
        tld: String?,
        minScore: Float?,
        premiumOnly: Int
    ): Int

    @Query("SELECT * FROM domains WHERE id = :id LIMIT 1")
    suspend fun getDomainById(id: String): DomainEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDomain(domain: DomainEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDomainsBulk(domains: List<DomainEntity>)

    @Query("DELETE FROM domains WHERE listId = :listId")
    suspend fun deleteDomainsByListId(listId: String)

    @Query("SELECT AVG(totalScore) FROM domains WHERE projectId = :projectId")
    fun getAverageScoreFlow(projectId: String): Flow<Float?>

    @Query("SELECT COUNT(*) FROM domains WHERE projectId = :projectId")
    fun getDomainCountFlow(projectId: String): Flow<Int>

    @Query("SELECT tld, COUNT(*) as count FROM domains WHERE projectId = :projectId GROUP BY tld ORDER BY count DESC")
    suspend fun getTldStats(projectId: String): List<TldCount>
}

data class TldCount(
    val tld: String,
    val count: Int
)
