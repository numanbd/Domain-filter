package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette Colors
val DarkBackground = Color(0xFF0F1115)       // Deep slate/charcoal background
val DarkSurface = Color(0xFF1C1F26)          // Lighter container/card surface
val DarkSurfaceVariant = Color(0xFF262933)   // Inner surfaces or highlighted items
val DarkBorder = Color(0xFF2D313E)           // Slate gray border color

val BlueAccent = Color(0xFF3B82F6)           // High contrast Blue
val BlueAccentLight = Color(0xFF60A5FA)      // Faded/secondary Blue accent
val BlueAccentGlow = Color(0x333B82F6)       // 20% alpha blue for glowing/pill selection

val ElegantSlate100 = Color(0xFFF1F5F9)      // Bright primary text
val ElegantSlate200 = Color(0xFFE2E8F0)      // Main body text
val ElegantSlate400 = Color(0xFF94A3B8)      // Muted metadata text
val ElegantSlate500 = Color(0xFF64748B)      // Highly muted caption text

val EmeraldSuccess = Color(0xFF34D399)       // Positive/Done status green
val EmeraldSuccessBg = Color(0x1A34D399)     // 10% done green background
val AmberWarning = Color(0xFFF59E0B)         // Warning color
val AmberWarningBg = Color(0x1AF59E0B)       // 10% warning background
val CrimsonError = Color(0xFFEF4444)         // Negative status/action red
val CrimsonErrorBg = Color(0x1AEF4444)       // 10% error background
