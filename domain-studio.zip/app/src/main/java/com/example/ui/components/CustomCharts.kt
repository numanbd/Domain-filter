package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TldCount

@Composable
fun TldDonutChart(
    data: List<TldCount>,
    modifier: Modifier = Modifier
) {
    val totalCount = data.sumOf { it.count }
    if (totalCount == 0) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("No TLD distribution data available", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    // Color palette for the slices
    val colorPalette = listOf(
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.secondary,
        MaterialTheme.colorScheme.tertiary,
        MaterialTheme.colorScheme.error,
        MaterialTheme.colorScheme.primaryContainer,
        MaterialTheme.colorScheme.secondaryContainer,
        MaterialTheme.colorScheme.tertiaryContainer
    )

    var animationTriggered by remember { mutableStateOf(false) }
    LaunchedEffect(data) {
        animationTriggered = true
    }

    val animatedSweep = animateFloatAsState(
        targetValue = if (animationTriggered) 360f else 0f,
        animationSpec = tween(durationMillis = 1000)
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Donut Canvas
        Box(
            modifier = Modifier
                .size(150.dp)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                var startAngle = -90f
                data.forEachIndexed { index, tldCount ->
                    val percentage = tldCount.count.toFloat() / totalCount
                    val sweepAngle = percentage * animatedSweep.value
                    val color = colorPalette[index % colorPalette.size]

                    drawArc(
                        color = color,
                        startAngle = startAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        style = Stroke(width = 24f, cap = StrokeCap.Round),
                        size = Size(size.width, size.height)
                    )
                    startAngle += percentage * 360f
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = totalCount.toString(),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "TLDs",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        // Legend
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            data.take(5).forEachIndexed { index, tldCount ->
                val color = colorPalette[index % colorPalette.size]
                val percentage = (tldCount.count.toFloat() / totalCount * 100).toInt()
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Canvas(modifier = Modifier.size(10.dp)) {
                        drawCircle(color = color)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = ".${tldCount.tld}",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.width(45.dp)
                    )
                    Text(
                        text = "${tldCount.count} ($percentage%)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (data.size > 5) {
                Text(
                    text = "+ ${data.size - 5} more TLDs",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 18.dp)
                )
            }
        }
    }
}

@Composable
fun ScoreDistributionBarChart(
    scores: List<Float>,
    modifier: Modifier = Modifier
) {
    if (scores.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("No score distribution data available", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    // Bucket scores into intervals of 10: 0-19, 20-39, 40-59, 60-79, 80-100
    val buckets = IntArray(5)
    scores.forEach { score ->
        when {
            score < 20f -> buckets[0]++
            score < 40f -> buckets[1]++
            score < 60f -> buckets[2]++
            score < 80f -> buckets[3]++
            else -> buckets[4]++
        }
    }

    val maxBucketVal = buckets.maxOrNull()?.coerceAtLeast(1) ?: 1
    val labels = listOf("0-19", "20-39", "40-59", "60-79", "80-100")
    val barColor = MaterialTheme.colorScheme.primary
    val barHoverColor = MaterialTheme.colorScheme.primaryContainer

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            buckets.forEachIndexed { index, valCount ->
                val ratio = valCount.toFloat() / maxBucketVal
                val animatedRatio = animateFloatAsState(
                    targetValue = ratio,
                    animationSpec = tween(durationMillis = 800, delayMillis = index * 100)
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    if (valCount > 0) {
                        Text(
                            text = valCount.toString(),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 10.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .fillMaxHeight(animatedRatio.value.coerceAtLeast(0.05f))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRoundRect(
                                color = if (index == 4) barColor else barHoverColor,
                                size = Size(size.width, size.height),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            labels.forEach { label ->
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 9.sp,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}
