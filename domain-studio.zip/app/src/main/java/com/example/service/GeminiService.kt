package com.example.service

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini Request/Response Models ---

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    @Json(name = "responseMimeType") val responseMimeType: String? = null,
    @Json(name = "temperature") val temperature: Float? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "generationConfig") val generationConfig: GenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @Json(name = "candidates") val candidates: List<Candidate>?
)

// --- Domain AI Evaluation Model ---

@JsonClass(generateAdapter = true)
data class AiDomainEvaluation(
    @Json(name = "score") val score: Int,
    @Json(name = "brandability") val brandability: Int,
    @Json(name = "commerciality") val commerciality: Int,
    @Json(name = "recommended_categories") val recommendedCategories: List<String>,
    @Json(name = "recommended_industries") val recommendedIndustries: List<String>,
    @Json(name = "strengths") val strengths: List<String>,
    @Json(name = "weaknesses") val weaknesses: List<String>,
    @Json(name = "buyer_profile") val buyerProfile: String,
    @Json(name = "explanation") val explanation: String
)

// --- Retrofit Interface ---

interface GeminiApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

// --- Service Object ---

object GeminiService {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val apiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    /**
     * Executes AI-assisted evaluation using Gemini API.
     * If the key is missing or invalid, or if there is no internet,
     * it falls back to a clever heuristic generator to prevent user friction.
     */
    suspend fun evaluateDomain(
        domainName: String,
        profileName: String,
        model: String = "gemini-3.5-flash"
    ): AiDomainEvaluation {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // No API Key, use intelligent simulated analyzer
            return generateLocalEvaluation(domainName, profileName, "No API Key configured. Please enter a valid Gemini API Key in the Secrets Panel.")
        }

        val prompt = """
            Perform a rigorous domain investment appraisal of the domain name '$domainName' under the perspective of a '$profileName' evaluation profile.
            Analyze its phonetic elegance, premium brand potential, commercial application, startup suitability, strengths, and structural weaknesses.
            
            Return a JSON object conforming STRICTLY to this schema:
            {
              "score": (integer between 0 and 100, representing general investment score),
              "brandability": (integer between 0 and 100),
              "commerciality": (integer between 0 and 100),
              "recommended_categories": ["SaaS", "E-commerce", etc. max 3 categories],
              "recommended_industries": ["AI & Tech", "Finance", etc. max 3 industries],
              "strengths": ["list of 2-3 specific positive characteristics of the domain"],
              "weaknesses": ["list of 1-2 limitations or structural issues"],
              "buyer_profile": "Short 1-sentence summary of the ideal buyer",
              "explanation": "Detailed 2-3 sentence technical analysis of why this domain holds or lacks commercial utility."
            }
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = prompt)))
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2f
            ),
            systemInstruction = Content(
                parts = listOf(Part(text = "You are a professional elite domain portfolio broker and brand strategy architect. Respond only with valid JSON."))
            )
        )

        return try {
            val response = apiService.generateContent(model, apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw Exception("Empty AI response")
            
            // Parse response JSON using Moshi
            val adapter = moshi.adapter(AiDomainEvaluation::class.java)
            adapter.fromJson(jsonText) ?: throw Exception("JSON Parsing returned null")
        } catch (e: Exception) {
            // Network failure or parsing error, fallback gracefully
            generateLocalEvaluation(domainName, profileName, "Offline or API Error fallback. Technical Details: ${e.message}")
        }
    }

    /**
     * Generate an intelligent local evaluation report if offline or if no API key is set.
     */
    fun generateLocalEvaluation(domainName: String, profileName: String, reason: String): AiDomainEvaluation {
        val cleanDomain = domainName.substringBefore('.').lowercase()
        val tld = domainName.substringAfterLast('.').lowercase()
        val isCom = tld == "com"

        // Local evaluation logic based on name heuristics
        val isShort = cleanDomain.length <= 4
        val hasPremiumVowels = cleanDomain.count { it in listOf('a', 'e', 'i', 'o', 'u') } >= 2
        
        val baseScore = if (isCom) 75 else 55
        val lengthBonus = if (isShort) 20 else 5
        val linguisticBonus = if (hasPremiumVowels) 5 else -10
        val finalScore = (baseScore + lengthBonus + linguisticBonus).coerceIn(10, 98)

        val brandability = (60 + lengthBonus + linguisticBonus).coerceIn(20, 95)
        val commerciality = if (isCom) 85 else 55

        val categories = mutableListOf<String>()
        val industries = mutableListOf<String>()

        if (cleanDomain.contains("pay") || cleanDomain.contains("coin") || cleanDomain.contains("wallet") || cleanDomain.contains("cash")) {
            categories.add("Fintech")
            categories.add("Crypto")
            industries.add("Finance & Banking")
            industries.add("Web3")
        } else if (cleanDomain.contains("ai") || cleanDomain.contains("bot") || cleanDomain.contains("gpt") || cleanDomain.contains("neuro")) {
            categories.add("AI & Automation")
            categories.add("SaaS")
            industries.add("Artificial Intelligence")
            industries.add("Enterprise Tech")
        } else if (isShort) {
            categories.add("Ultra-Premium Branding")
            categories.add("Corporate Venture")
            industries.add("Multi-Sector Holdco")
            industries.add("Premium VC Portfolio")
        } else {
            categories.add("General Tech")
            categories.add("E-commerce")
            industries.add("Online Retail")
            industries.add("Digital Media")
        }

        if (categories.isEmpty()) categories.add("SaaS")
        if (industries.isEmpty()) industries.add("Information Tech")

        val strengths = mutableListOf<String>()
        val weaknesses = mutableListOf<String>()

        if (isCom) {
            strengths.add("TLD Authority: .com is the gold-standard for premium domains.")
        } else {
            strengths.add("Modern TLD: .$tld is popular among tech innovators.")
            weaknesses.add("Lacks the global authority and safety-association of .com.")
        }

        if (isShort) {
            strengths.add("Short and Memorable: Only ${cleanDomain.length} letters.")
        } else {
            weaknesses.add("Longer character length increases spelling ambiguity.")
        }

        if (hasPremiumVowels) {
            strengths.add("Pronounceable structure with healthy vowel-consonant harmony.")
        } else {
            weaknesses.add("Heavy consonant clusters can make pronunciation difficult.")
        }

        val profileDesc = when (profileName.lowercase()) {
            "balanced" -> "general investment profile"
            "brandable" -> "brandable focus profile"
            "short" -> "ultra-short structure profile"
            else -> "startup and tech readiness profile"
        }

        return AiDomainEvaluation(
            score = finalScore,
            brandability = brandability,
            commerciality = commerciality,
            recommendedCategories = categories.take(3),
            recommendedIndustries = industries.take(3),
            strengths = strengths.take(3),
            weaknesses = weaknesses.take(2),
            buyerProfile = "Perfect fit for an early-stage startup or corporate brand re-positioning.",
            explanation = "Evaluated via local heuristics ($reason). This domain has a clean SLD of '$cleanDomain'. Under a $profileDesc, its structural simplicity ranks it well for digital branding and memorability."
        )
    }
}
