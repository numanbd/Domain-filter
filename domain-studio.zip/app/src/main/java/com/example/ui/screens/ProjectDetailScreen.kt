package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DomainEntity
import com.example.data.DomainList
import com.example.service.RuleEngine
import com.example.ui.components.PermissionRequiredCard
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    viewModel: StudioViewModel,
    onNavigateToDomain: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val project by viewModel.selectedProject.collectAsState()
    val lists by viewModel.projectLists.collectAsState()
    val selectedList by viewModel.selectedList.collectAsState()

    val domains by viewModel.domainsList.collectAsState()
    val domainsCount by viewModel.domainsCount.collectAsState()
    val isAnalyzing by viewModel.isAnalyzing.collectAsState()

    // Filters and pagination
    val searchQuery by viewModel.searchPattern.collectAsState()
    val selectedTld by viewModel.filterTld.collectAsState()
    val minScore by viewModel.filterMinScore.collectAsState()
    val premiumOnly by viewModel.filterPremiumOnly.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()

    var showImportDialog by remember { mutableStateOf(false) }
    var importText by remember { mutableStateOf("") }
    var showPresetMenu by remember { mutableStateOf(false) }

    if (project == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a portfolio on the Dashboard to begin.")
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Portfolio Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = project!!.name,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = project!!.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Export Button
            IconButton(
                onClick = {
                    val csv = viewModel.exportToCsv()
                    Toast.makeText(context, "CSV exported containing ${domains.size} rows", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.testTag("export_csv_btn")
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = "Export CSV")
            }
        }

        // Profile Selection Selector Row
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Profile",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Scoring Strategy:",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
                
                Box {
                    TextButton(onClick = { showPresetMenu = true }) {
                        val active = RuleEngine.PROFILES.find { it.id == project!!.activeProfileId }
                        Text(active?.name ?: "Balanced", fontWeight = FontWeight.Bold)
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "expand")
                    }
                    DropdownMenu(
                        expanded = showPresetMenu,
                        onDismissRequest = { showPresetMenu = false }
                    ) {
                        RuleEngine.PROFILES.forEach { profile ->
                            DropdownMenuItem(
                                text = { Text(profile.name) },
                                onClick = {
                                    viewModel.changeProjectProfile(profile.id)
                                    showPresetMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Add Data Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { showImportDialog = true },
                modifier = Modifier
                    .weight(1f)
                    .testTag("import_domains_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Publish, contentDescription = "Import")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Import Domains")
            }

            OutlinedButton(
                onClick = {
                    viewModel.loadMockHighVolumeDataset(250)
                },
                modifier = Modifier
                    .weight(1.1f)
                    .testTag("stress_test_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.AutoMode, contentDescription = "Stress")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Simulate 250 Items")
            }
        }

        if (isAnalyzing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        // Sub-lists Horizonal Row
        if (lists.isNotEmpty()) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedList == null,
                        onClick = { viewModel.selectList(null) },
                        label = { Text("All Lists") }
                    )
                }
                items(lists) { item ->
                    FilterChip(
                        selected = selectedList?.id == item.id,
                        onClick = { viewModel.selectList(item) },
                        label = { Text(item.name) },
                        trailingIcon = {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Delete",
                                modifier = Modifier
                                    .size(14.dp)
                                    .clickable { viewModel.deleteList(item) }
                            )
                        }
                    )
                }
            }
        }

        // Search and Filter Sliders
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.searchPattern.value = it },
                    placeholder = { Text("Filter by domain keywords...", fontSize = 13.sp) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.searchPattern.value = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("search_domains_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )

                // Quick TLD Filters Row
                val tlds = listOf("com", "ai", "io", "co", "net", "org")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TLD:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        item {
                            SuggestionChip(
                                onClick = { viewModel.filterTld.value = null },
                                label = { Text("All") },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (selectedTld == null) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                                )
                            )
                        }
                        items(tlds) { tld ->
                            SuggestionChip(
                                onClick = { viewModel.filterTld.value = tld },
                                label = { Text(".$tld") },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (selectedTld == tld) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                                )
                            )
                        }
                    }
                }

                // Minimum Score slider + Premium only check
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = "Min Score: ${(minScore ?: 0f).toInt()}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(80.dp)
                        )
                        Slider(
                            value = minScore ?: 0f,
                            onValueChange = { viewModel.filterMinScore.value = if (it == 0f) null else it },
                            valueRange = 0f..100f,
                            modifier = Modifier.testTag("score_slider")
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
                        Checkbox(
                            checked = premiumOnly,
                            onCheckedChange = { viewModel.filterPremiumOnly.value = it },
                            modifier = Modifier.testTag("premium_checkbox")
                        )
                        Text("Premium", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Domains list table with pagination
        Box(modifier = Modifier.weight(1f)) {
            if (domains.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.FilterListOff, contentDescription = "Empty", modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("No matching domains found in this view.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(domains) { item ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectDomain(item)
                                    onNavigateToDomain()
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.domainName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        if (item.isPremium) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Default.Stars,
                                                contentDescription = "Premium Status",
                                                tint = Color(0xFFD4AF37),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text("SLD: ${item.sld}", fontSize = 9.sp) }
                                        )
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text("TLD: .${item.tld}", fontSize = 9.sp) }
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Rule Score Badge
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Score", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = when {
                                                item.totalScore >= 80f -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                                item.totalScore >= 60f -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                                                else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
                                            }
                                        ) {
                                            Text(
                                                text = String.format("%.0f", item.totalScore),
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = when {
                                                    item.totalScore >= 80f -> MaterialTheme.colorScheme.primary
                                                    item.totalScore >= 60f -> MaterialTheme.colorScheme.secondary
                                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                },
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    // AI Evaluated Indicator Sparkle
                                    if (item.aiScore > 0) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "AI Evaluated",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Pagination Bar controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val totalPages = ((domainsCount - 1) / viewModel.pageSize) + 1
            val safePages = if (totalPages < 1) 1 else totalPages
            
            Text(
                text = "Showing ${domains.size} of $domainsCount (Page ${currentPage + 1} of $safePages)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = { if (currentPage > 0) viewModel.currentPage.value = currentPage - 1 },
                    enabled = currentPage > 0,
                    modifier = Modifier.testTag("prev_page_btn")
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                }

                IconButton(
                    onClick = { if (currentPage + 1 < safePages) viewModel.currentPage.value = currentPage + 1 },
                    enabled = currentPage + 1 < safePages,
                    modifier = Modifier.testTag("next_page_btn")
                ) {
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Forward")
                }
            }
        }
    }

    // Import domains dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        if (importText.isNotEmpty()) {
                            viewModel.importDomains(importText)
                            showImportDialog = false
                            importText = ""
                        }
                    },
                    modifier = Modifier.testTag("submit_import_btn")
                ) {
                    Text("Evaluate & Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel")
                }
            },
            title = { Text("Import Portfolio List") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Paste one domain per line. Syntaxes are automatically parsed and evaluated locally.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = importText,
                        onValueChange = { importText = it },
                        placeholder = { Text("google.com\nopenai.io\ncrypto.co\npremium.ai") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .testTag("import_domains_text_input")
                    )
                }
            }
        )
    }
}
