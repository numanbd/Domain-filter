package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val ElegantDarkColorScheme = darkColorScheme(
    primary = BlueAccent,
    onPrimary = ElegantSlate100,
    primaryContainer = BlueAccentGlow,
    onPrimaryContainer = BlueAccentLight,
    secondary = BlueAccentLight,
    onSecondary = DarkSurface,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = ElegantSlate200,
    tertiary = EmeraldSuccess,
    onTertiary = DarkSurface,
    background = DarkBackground,
    onBackground = ElegantSlate200,
    surface = DarkSurface,
    onSurface = ElegantSlate100,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = ElegantSlate400,
    outline = DarkBorder,
    error = CrimsonError,
    onError = ElegantSlate100,
    errorContainer = CrimsonErrorBg,
    onErrorContainer = ElegantSlate200
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to Elegant Dark theme
    dynamicColor: Boolean = false, // Disable dynamic colors to enforce the requested brand theme
    content: @Composable () -> Unit,
) {
    // We enforce the Elegant Dark theme for this design
    val colorScheme = ElegantDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
