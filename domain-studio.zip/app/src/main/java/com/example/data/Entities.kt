package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val email: String,
    val fullName: String,
    val role: String, // SUPERUSER, ANALYST, VIEWER
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String?,
    val userEmail: String,
    val action: String,
    val resource: String?,
    val status: String,
    val details: String,
    val ipAddress: String = "127.0.0.1"
)

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String,
    val preferredAiMode: String = "HYBRID", // RULE_ONLY, AI_ONLY, HYBRID
    val activeProfileId: String = "balanced", // balanced, brandable, short, startup
    val tags: String = "", // Comma-separated
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "domain_lists",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class DomainList(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val sourceType: String, // manual, file, mock
    val originalFilename: String?,
    val recordCount: Int = 0,
    val duplicateCount: Int = 0,
    val invalidCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "domains",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = DomainList::class,
            parentColumns = ["id"],
            childColumns = ["listId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["projectId"]),
        Index(value = ["listId"]),
        Index(value = ["domainName"]),
        Index(value = ["totalScore"]),
        Index(value = ["isPremium"])
    ]
)
data class DomainEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val listId: String,
    val domainName: String,
    val tld: String,
    val sld: String,
    val ruleScore: Float,
    val aiScore: Float = 0.0f,
    val totalScore: Float,
    val isPremium: Boolean,
    
    // Serialized JSON payloads
    val linguisticAnalysisJson: String, // JSON metadata from Rule Engine
    val aiEvaluationJson: String? = null, // JSON metadata from Gemini
    
    val createdAt: Long = System.currentTimeMillis()
)
