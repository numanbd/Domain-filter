package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.service.DomainParser
import com.example.service.GeminiService
import com.example.service.RuleEngine
import com.example.service.AiDomainEvaluation
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.StringWriter

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val userDao = db.userDao()
    private val auditLogDao = db.auditLogDao()
    private val projectDao = db.projectDao()
    private val domainListDao = db.domainListDao()
    private val domainDao = db.domainDao()

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val parsingResultAdapter = moshi.adapter(DomainParser.ParsingResult::class.java)
    private val aiEvaluationAdapter = moshi.adapter(AiDomainEvaluation::class.java)

    // --- State: Auth & User Session Simulation ---
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _allUsers = MutableStateFlow<List<User>>(emptyList())
    val allUsers: StateFlow<List<User>> = _allUsers.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    // --- State: Domain Studio Data ---
    val projects: StateFlow<List<Project>> = projectDao.getAllProjectsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedProject = MutableStateFlow<Project?>(null)
    val selectedProject: StateFlow<Project?> = _selectedProject.asStateFlow()

    private val _projectLists = MutableStateFlow<List<DomainList>>(emptyList())
    val projectLists: StateFlow<List<DomainList>> = _projectLists.asStateFlow()

    private val _selectedList = MutableStateFlow<DomainList?>(null)
    val selectedList: StateFlow<DomainList?> = _selectedList.asStateFlow()

    // --- Pagination, Search, and Filtering State ---
    val searchPattern = MutableStateFlow("")
    val filterTld = MutableStateFlow<String?>(null)
    val filterMinScore = MutableStateFlow<Float?>(null)
    val filterPremiumOnly = MutableStateFlow(false)

    val currentPage = MutableStateFlow(0)
    val pageSize = 20

    private val _domainsList = MutableStateFlow<List<DomainEntity>>(emptyList())
    val domainsList: StateFlow<List<DomainEntity>> = _domainsList.asStateFlow()

    private val _domainsCount = MutableStateFlow(0)
    val domainsCount: StateFlow<Int> = _domainsCount.asStateFlow()

    private val _selectedDomain = MutableStateFlow<DomainEntity?>(null)
    val selectedDomain: StateFlow<DomainEntity?> = _selectedDomain.asStateFlow()

    // --- Metrics State ---
    private val _averageScore = MutableStateFlow(0.0f)
    val averageScore: StateFlow<Float> = _averageScore.asStateFlow()

    private val _tldStats = MutableStateFlow<List<TldCount>>(emptyList())
    val tldStats: StateFlow<List<TldCount>> = _tldStats.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    // --- Config & Scoring Presets ---
    private val _activeProfile = MutableStateFlow(RuleEngine.PROFILES[0])
    val activeProfile: StateFlow<RuleEngine.ScoringProfile> = _activeProfile.asStateFlow()

    init {
        // Initialize Default User & System Data
        viewModelScope.launch {
            setupDefaultSession()
            observeSelectedProject()
            observeFiltersAndPagination()
            loadAuditLogs()
            loadUsers()
        }
    }

    private suspend fun setupDefaultSession() {
        val defaultEmail = "admin@domainstudio.com"
        var user = userDao.getUserByEmail(defaultEmail)
        if (user == null) {
            user = User(
                email = defaultEmail,
                fullName = "Lead Architect Admin",
                role = "SUPERUSER"
            )
            userDao.insertUser(user)
        }
        _currentUser.value = user
        logAction("USER_SESSION_START", "SYSTEM", "SUCCESS", "Initialized default user session for ${user.fullName}")
    }

    private fun loadUsers() {
        viewModelScope.launch {
            userDao.getAllUsers().collect {
                _allUsers.value = it
            }
        }
    }

    private fun loadAuditLogs() {
        viewModelScope.launch {
            auditLogDao.getRecentLogs().collect {
                _auditLogs.value = it
            }
        }
    }

    private fun observeSelectedProject() {
        viewModelScope.launch {
            _selectedProject.collectLatest { project ->
                if (project != null) {
                    domainListDao.getListsForProject(project.id).collectLatest { lists ->
                        _projectLists.value = lists
                        _selectedList.value = lists.firstOrNull()
                    }
                } else {
                    _projectLists.value = emptyList()
                    _selectedList.value = null
                }
            }
        }
    }

    private fun observeFiltersAndPagination() {
        viewModelScope.launch {
            combine(
                listOf(
                    _selectedProject,
                    _selectedList,
                    searchPattern,
                    filterTld,
                    filterMinScore,
                    filterPremiumOnly,
                    currentPage
                )
            ) { array ->
                val proj = array[0] as Project?
                val list = array[1] as DomainList?
                val search = array[2] as String
                val tld = array[3] as String?
                val minScore = array[4] as Float?
                val premOnly = array[5] as Boolean
                val page = array[6] as Int

                if (proj != null) {
                    val searchString = if (search.trim().isEmpty()) null else "%${search.trim().lowercase()}%"
                    val premInt = if (premOnly) 1 else 0
                    
                    val domains = withContext(Dispatchers.IO) {
                        domainDao.getFilteredDomains(
                            projectId = proj.id,
                            listId = list?.id,
                            search = searchString,
                            tld = tld,
                            minScore = minScore,
                            premiumOnly = premInt,
                            limit = pageSize,
                            offset = page * pageSize
                        )
                    }
                    val count = withContext(Dispatchers.IO) {
                        domainDao.getFilteredDomainsCount(
                            projectId = proj.id,
                            listId = list?.id,
                            search = searchString,
                            tld = tld,
                            minScore = minScore,
                            premiumOnly = premInt
                        )
                    }
                    _domainsList.value = domains
                    _domainsCount.value = count
                    
                    // Refresh metrics in background
                    refreshMetrics(proj.id)
                } else {
                    _domainsList.value = emptyList()
                    _domainsCount.value = 0
                }
            }.collect()
        }
    }

    private suspend fun refreshMetrics(projectId: String) {
        withContext(Dispatchers.IO) {
            val stats = domainDao.getTldStats(projectId)
            _tldStats.value = stats
            
            domainDao.getAverageScoreFlow(projectId).collectLatest { avg ->
                _averageScore.value = avg ?: 0.0f
            }
        }
    }

    // --- Operations ---

    fun loginAsUser(user: User) {
        _currentUser.value = user
        viewModelScope.launch {
            logAction("USER_LOGIN", "USER", "SUCCESS", "Logged in as ${user.fullName} (${user.role})")
        }
    }

    fun switchRole(role: String) {
        val current = _currentUser.value ?: return
        val updated = current.copy(role = role)
        viewModelScope.launch {
            userDao.insertUser(updated)
            _currentUser.value = updated
            logAction("USER_ROLE_SWITCH", "USER", "SUCCESS", "Role switched to $role")
        }
    }

    fun createMockUser(name: String, email: String, role: String) {
        viewModelScope.launch {
            if (!hasPermission("domain:write")) {
                logAction("USER_CREATE", "USER", "DENIED", "Insufficient permissions")
                return@launch
            }
            val newUser = User(fullName = name, email = email, role = role)
            userDao.insertUser(newUser)
            logAction("USER_CREATE", "USER", "SUCCESS", "Created user ${newUser.fullName} with role $role")
            loadUsers()
        }
    }

    fun deleteUser(id: String) {
        viewModelScope.launch {
            if (!hasPermission("domain:delete")) {
                logAction("USER_DELETE", "USER", "DENIED", "Insufficient permissions")
                return@launch
            }
            userDao.deleteUserById(id)
            logAction("USER_DELETE", "USER", "SUCCESS", "Deleted user with ID $id")
            loadUsers()
        }
    }

    fun selectProject(project: Project?) {
        _selectedProject.value = project
        currentPage.value = 0
        if (project != null) {
            _activeProfile.value = RuleEngine.PROFILES.find { it.id == project.activeProfileId } ?: RuleEngine.PROFILES[0]
            viewModelScope.launch {
                logAction("PROJECT_SELECT", "PROJECT", "SUCCESS", "Selected project '${project.name}'")
            }
        }
    }

    fun selectList(list: DomainList?) {
        _selectedList.value = list
        currentPage.value = 0
    }

    fun selectDomain(domain: DomainEntity?) {
        _selectedDomain.value = domain
    }

    fun createProject(name: String, description: String, profileId: String) {
        viewModelScope.launch {
            if (!hasPermission("domain:write")) {
                logAction("PROJECT_CREATE", "PROJECT", "DENIED", "Insufficient permissions")
                return@launch
            }
            val newProj = Project(
                name = name,
                description = description,
                activeProfileId = profileId
            )
            withContext(Dispatchers.IO) {
                projectDao.insertProject(newProj)
            }
            logAction("PROJECT_CREATE", "PROJECT", "SUCCESS", "Created new project '$name'")
            selectProject(newProj)
        }
    }

    fun deleteProject(project: Project) {
        viewModelScope.launch {
            if (!hasPermission("domain:delete")) {
                logAction("PROJECT_DELETE", "PROJECT", "DENIED", "Insufficient permissions")
                return@launch
            }
            withContext(Dispatchers.IO) {
                projectDao.deleteProjectById(project.id)
            }
            logAction("PROJECT_DELETE", "PROJECT", "SUCCESS", "Deleted project '${project.name}'")
            if (_selectedProject.value?.id == project.id) {
                selectProject(null)
            }
        }
    }

    fun changeProjectProfile(profileId: String) {
        val project = _selectedProject.value ?: return
        val profile = RuleEngine.PROFILES.find { it.id == profileId } ?: return
        _activeProfile.value = profile
        
        viewModelScope.launch {
            val updated = project.copy(activeProfileId = profileId, lastUpdated = System.currentTimeMillis())
            withContext(Dispatchers.IO) {
                projectDao.updateProject(updated)
            }
            _selectedProject.value = updated
            logAction("PROJECT_PROFILE_UPDATE", "PROJECT", "SUCCESS", "Scoring profile changed to '${profile.name}'")
            
            // Recalculate scores for all domains in this project under the new profile
            recalculateProjectScores(project.id, profileId)
        }
    }

    private suspend fun recalculateProjectScores(projectId: String, profileId: String) {
        _isAnalyzing.value = true
        withContext(Dispatchers.IO) {
            // Load all domains
            var offset = 0
            val batchSize = 100
            var fetched: List<DomainEntity>
            do {
                fetched = domainDao.getFilteredDomains(
                    projectId = projectId,
                    listId = null,
                    search = null,
                    tld = null,
                    minScore = null,
                    premiumOnly = 0,
                    limit = batchSize,
                    offset = offset
                )
                val updatedBatch = fetched.map { d ->
                    val parsing = parsingResultAdapter.fromJson(d.linguisticAnalysisJson)
                    if (parsing != null) {
                        val newScore = RuleEngine.score(parsing, profileId)
                        d.copy(
                            ruleScore = newScore.totalScore,
                            totalScore = if (d.aiScore > 0) (newScore.totalScore + d.aiScore) / 2f else newScore.totalScore,
                            isPremium = newScore.isPremium
                        )
                    } else d
                }
                domainDao.insertDomainsBulk(updatedBatch)
                offset += batchSize
            } while (fetched.isNotEmpty())
            
            logAction("DOMAINS_RECALCULATED", "DOMAINS", "SUCCESS", "Recalculated all domain scores using profile: $profileId")
        }
        _isAnalyzing.value = false
        // Trigger list refresh
        val currPage = currentPage.value
        currentPage.value = -1
        currentPage.value = currPage
    }

    fun importDomains(rawInput: String) {
        val proj = _selectedProject.value ?: return
        viewModelScope.launch {
            if (!hasPermission("domain:write")) {
                logAction("DOMAINS_IMPORT", "DOMAINS", "DENIED", "Insufficient permissions to import domains")
                return@launch
            }
            _isAnalyzing.value = true
            withContext(Dispatchers.IO) {
                val lines = rawInput.lines()
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && !it.startsWith("#") }
                
                if (lines.isEmpty()) return@withContext

                val listEntity = DomainList(
                    projectId = proj.id,
                    name = "Manual Import (${lines.size} items)",
                    sourceType = "manual",
                    originalFilename = null,
                    recordCount = lines.size
                )
                domainListDao.insertList(listEntity)

                val domainEntities = mutableListOf<DomainEntity>()
                var dupCount = 0
                var invalidCount = 0

                lines.forEach { line ->
                    val result = DomainParser.parse(line)
                    if (!result.syntax.isValid) {
                        invalidCount++
                    }
                    val scoring = RuleEngine.score(result, proj.activeProfileId)
                    val parsingJson = parsingResultAdapter.toJson(result)

                    domainEntities.add(
                        DomainEntity(
                            projectId = proj.id,
                            listId = listEntity.id,
                            domainName = result.syntax.normalizedName,
                            tld = result.syntax.tld,
                            sld = result.syntax.sld,
                            ruleScore = scoring.totalScore,
                            totalScore = scoring.totalScore,
                            isPremium = scoring.isPremium,
                            linguisticAnalysisJson = parsingJson
                        )
                    )
                }

                domainDao.insertDomainsBulk(domainEntities)
                
                val updatedList = listEntity.copy(
                    recordCount = domainEntities.size,
                    duplicateCount = dupCount,
                    invalidCount = invalidCount
                )
                domainListDao.insertList(updatedList)

                logAction(
                    "DOMAINS_IMPORT",
                    "DOMAINS",
                    "SUCCESS",
                    "Imported ${domainEntities.size} domains (invalid: $invalidCount) into list '${updatedList.name}'"
                )
            }
            _isAnalyzing.value = false
            selectProject(proj) // Refresh project lists and domains
        }
    }

    fun loadMockHighVolumeDataset(size: Int) {
        val proj = _selectedProject.value ?: return
        viewModelScope.launch {
            if (!hasPermission("domain:write")) {
                logAction("DOMAINS_IMPORT", "DOMAINS", "DENIED", "Insufficient permissions for batch generation")
                return@launch
            }
            _isAnalyzing.value = true
            withContext(Dispatchers.IO) {
                val prefixes = listOf("apex", "zenith", "hyper", "cyber", "quantum", "alpha", "nova", "omega", "smart", "sync", "flow", "cloud", "core", "pay", "vault", "prime")
                val roots = listOf("pay", "coin", "ledger", "bot", "ai", "labs", "grid", "stream", "chain", "sphere", "cube", "hub", "wave", "matrix", "nexus", "volt", "intel")
                val suffixes = listOf("ify", "ly", "io", "hq", "base", "net", "app", "tech", "zone", "link", "lab", "space", "well", "wise", "press", "go", "run")
                val tlds = listOf("com", "com", "com", "io", "co", "ai", "net", "org", "dev", "app", "xyz")

                val generatedDomains = mutableListOf<String>()
                
                // Add some high quality organic ones to be sure
                generatedDomains.add("paybolt.com")
                generatedDomains.add("neurogrid.ai")
                generatedDomains.add("zenithchain.io")
                generatedDomains.add("syncvault.co")
                generatedDomains.add("cloudmatrix.com")
                generatedDomains.add("alphaflow.dev")

                for (i in 1..size) {
                    val p = prefixes.random()
                    val r = roots.random()
                    val s = suffixes.random()
                    val t = tlds.random()
                    val hasP = Math.random() > 0.5
                    val hasS = Math.random() > 0.3
                    
                    val sld = buildString {
                        if (hasP) append(p)
                        append(r)
                        if (hasS) append(s)
                        if (Math.random() > 0.95) append((1..9).random()) // occasional number
                    }
                    generatedDomains.add("$sld.$t")
                }

                val listEntity = DomainList(
                    projectId = proj.id,
                    name = "Stress Batches - $size items",
                    sourceType = "mock",
                    originalFilename = "simulated_portfolio.csv",
                    recordCount = generatedDomains.size
                )
                domainListDao.insertList(listEntity)

                val domainEntities = generatedDomains.chunked(250).flatMap { batch ->
                    batch.map { domain ->
                        val result = DomainParser.parse(domain)
                        val scoring = RuleEngine.score(result, proj.activeProfileId)
                        val parsingJson = parsingResultAdapter.toJson(result)

                        DomainEntity(
                            projectId = proj.id,
                            listId = listEntity.id,
                            domainName = result.syntax.normalizedName,
                            tld = result.syntax.tld,
                            sld = result.syntax.sld,
                            ruleScore = scoring.totalScore,
                            totalScore = scoring.totalScore,
                            isPremium = scoring.isPremium,
                            linguisticAnalysisJson = parsingJson
                        )
                    }
                }

                domainDao.insertDomainsBulk(domainEntities)

                logAction(
                    "DOMAINS_GENERATED",
                    "DOMAINS",
                    "SUCCESS",
                    "Successfully generated high-volume dataset of ${domainEntities.size} items for stress testing."
                )
            }
            _isAnalyzing.value = false
            selectProject(proj)
        }
    }

    fun runAiEvaluation(domain: DomainEntity) {
        if (!hasPermission("domain:write")) {
            viewModelScope.launch {
                logAction("AI_EVALUATION", "AI", "DENIED", "Viewer role cannot trigger expensive AI model reasoning.")
            }
            return
        }
        
        _isAiLoading.value = true
        viewModelScope.launch {
            logAction("AI_EVALUATION_START", "AI", "PENDING", "Evaluating domain '${domain.domainName}' via Gemini AI")
            
            try {
                val eval = withContext(Dispatchers.IO) {
                    GeminiService.evaluateDomain(
                        domainName = domain.domainName,
                        profileName = _activeProfile.value.name
                    )
                }

                val evalJson = aiEvaluationAdapter.toJson(eval)
                val updatedDomain = domain.copy(
                    aiScore = eval.score.toFloat(),
                    totalScore = (domain.ruleScore + eval.score.toFloat()) / 2f,
                    aiEvaluationJson = evalJson
                )

                withContext(Dispatchers.IO) {
                    domainDao.insertDomain(updatedDomain)
                }

                _selectedDomain.value = updatedDomain
                logAction("AI_EVALUATION_SUCCESS", "AI", "SUCCESS", "Successfully parsed and applied structured Gemini AI scores for '${domain.domainName}'")
            } catch (e: Exception) {
                logAction("AI_EVALUATION_FAIL", "AI", "FAIL", "Gemini analysis error: ${e.message}")
            } finally {
                _isAiLoading.value = false
                // Trigger view layout updates
                selectProject(_selectedProject.value)
            }
        }
    }

    fun deleteList(list: DomainList) {
        viewModelScope.launch {
            if (!hasPermission("domain:delete")) {
                logAction("LIST_DELETE", "PROJECT", "DENIED", "Insufficient permissions")
                return@launch
            }
            withContext(Dispatchers.IO) {
                domainListDao.deleteListById(list.id)
            }
            logAction("LIST_DELETE", "PROJECT", "SUCCESS", "Deleted list '${list.name}'")
            if (_selectedList.value?.id == list.id) {
                _selectedList.value = _projectLists.value.firstOrNull()
            }
            selectProject(_selectedProject.value)
        }
    }

    fun exportToCsv(): String {
        val proj = _selectedProject.value ?: return ""
        val list = _selectedList.value
        val writer = StringWriter()
        writer.append("Domain,SLD,TLD,Rule Score,AI Score,Total Score,Premium\n")
        
        val listName = list?.name ?: "All Project Lists"
        viewModelScope.launch {
            logAction("CSV_EXPORT", "DOMAINS", "SUCCESS", "Exported CSV list for '$listName' containing ${_domainsList.value.size} rows")
        }

        _domainsList.value.forEach { d ->
            writer.append("${d.domainName},${d.sld},${d.tld},${d.ruleScore},${d.aiScore},${d.totalScore},${d.isPremium}\n")
        }
        return writer.toString()
    }

    fun clearAuditLogs() {
        viewModelScope.launch {
            if (!hasPermission("domain:delete")) {
                logAction("AUDIT_CLEAR", "SYSTEM", "DENIED", "Only SUPERUSER admins can clean historical audit records.")
                return@launch
            }
            withContext(Dispatchers.IO) {
                auditLogDao.clearLogs()
            }
            logAction("AUDIT_CLEAR", "SYSTEM", "SUCCESS", "Cleared all system audit database records.")
            loadAuditLogs()
        }
    }

    // --- Helpers ---

    fun hasPermission(permission: String): Boolean {
        val current = _currentUser.value ?: return false
        return when (current.role) {
            "SUPERUSER" -> true
            "ANALYST" -> permission != "domain:delete"
            "VIEWER" -> permission == "domain:read"
            else -> false
        }
    }

    private suspend fun logAction(action: String, resource: String, status: String, details: String) {
        val user = _currentUser.value
        val log = AuditLog(
            userId = user?.id,
            userEmail = user?.email ?: "guest@system.local",
            action = action,
            resource = resource,
            status = status,
            details = details
        )
        withContext(Dispatchers.IO) {
            auditLogDao.insertLog(log)
        }
        loadAuditLogs()
    }

    fun getLinguisticMetadata(domain: DomainEntity): DomainParser.ParsingResult? {
        return try {
            parsingResultAdapter.fromJson(domain.linguisticAnalysisJson)
        } catch (e: Exception) {
            null
        }
    }

    fun getAiEvaluation(domain: DomainEntity): AiDomainEvaluation? {
        val json = domain.aiEvaluationJson ?: return null
        return try {
            aiEvaluationAdapter.fromJson(json)
        } catch (e: Exception) {
            null
        }
    }
}
