package com.example.service

import java.util.Locale

object DomainParser {

    data class LinguisticMetadata(
        val charCount: Int,
        val vowelCount: Int,
        val consonantCount: Int,
        val syllableCount: Int,
        val vowelRatio: Float,
        val hasNumbers: Boolean,
        val hasHyphens: Boolean,
        val isPronounceable: Boolean,
        val visualScore: Float, // 0 to 100
        val radioTestScore: Float // 0 to 100
    )

    data class SyntaxMetadata(
        val rawInput: String,
        val normalizedName: String,
        val sld: String, // Second-Level Domain e.g. "google"
        val tld: String, // Top-Level Domain e.g. "com"
        val isValid: Boolean
    )

    data class ParsingResult(
        val syntax: SyntaxMetadata,
        val linguistics: LinguisticMetadata,
        val warnings: List<String>
    )

    private val VOWELS = setOf('a', 'e', 'i', 'o', 'u', 'y')
    private val CONSONANTS = setOf(
        'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 
        'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'z'
    )
    
    val SUPPORTED_TLDS = setOf(
        "com", "net", "org", "io", "co", "ai", "xyz", "app", "dev"
    )

    fun parse(rawInput: String): ParsingResult {
        // Stage 2: Normalization
        var normalized = rawInput.trim().lowercase(Locale.ROOT)
        normalized = normalized.removePrefix("https://").removePrefix("http://")
        normalized = normalized.removePrefix("www.")
        normalized = normalized.substringBefore('/')

        // Stage 1 & 3: Syntax analysis
        val warnings = mutableListOf<String>()
        val parts = normalized.split('.')
        
        val isValidFormat = parts.size >= 2 && parts.all { it.isNotEmpty() } && 
                normalized.matches(Regex("^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$"))

        var sld = ""
        var tld = ""
        var isValid = isValidFormat

        if (isValidFormat && parts.size >= 2) {
            tld = parts.last()
            sld = parts[parts.size - 2]
            
            if (!SUPPORTED_TLDS.contains(tld)) {
                warnings.add("TLD .$tld is outside primary priority categories, which may affect liquidity.")
            }
        } else {
            isValid = false
            sld = normalized.substringBefore('.')
            tld = if (normalized.contains('.')) normalized.substringAfterLast('.') else ""
            warnings.add("Syntax validation failed: domain format is invalid.")
        }

        val cleanSld = sld.replace("-", "")
        val charCount = cleanSld.length
        
        var vowelCount = 0
        var consonantCount = 0
        for (char in cleanSld) {
            if (VOWELS.contains(char)) vowelCount++
            else if (CONSONANTS.contains(char)) consonantCount++
        }

        val syllableCount = countSyllables(cleanSld)
        val vowelRatio = if (charCount > 0) vowelCount.toFloat() / charCount else 0.0f
        val hasNumbers = sld.any { it.isDigit() }
        val hasHyphens = sld.contains('-')

        // Pronounceability heuristic: penalize 3+ consecutive consonants or 3+ consecutive vowels
        val pattern = getVowelConsonantPattern(cleanSld)
        val isPronounceable = charCount > 0 && 
                !pattern.contains("CCCC") && 
                !pattern.contains("VVV") &&
                !(charCount >= 5 && syllableCount == 1 && consonantCount > vowelCount * 3)

        // Visual Simplicity Score (0-100)
        var visualScore = 100f
        if (hasNumbers) visualScore -= 30f
        if (hasHyphens) visualScore -= 20f
        val excessiveLengthPenalties = (charCount - 8).coerceAtLeast(0) * 5f
        visualScore = (visualScore - excessiveLengthPenalties).coerceIn(0f, 100f)

        // Radio Test Score (0-100)
        var radioScore = 100f
        if (!isPronounceable) radioScore -= 40f
        if (hasHyphens) radioScore -= 25f
        if (hasNumbers) radioScore -= 35f
        radioScore -= (syllableCount * 10f)
        radioScore = radioScore.coerceIn(0f, 100f)

        val linguistics = LinguisticMetadata(
            charCount = charCount,
            vowelCount = vowelCount,
            consonantCount = consonantCount,
            syllableCount = syllableCount,
            vowelRatio = vowelRatio,
            hasNumbers = hasNumbers,
            hasHyphens = hasHyphens,
            isPronounceable = isPronounceable,
            visualScore = visualScore,
            radioTestScore = radioScore
        )

        return ParsingResult(
            syntax = SyntaxMetadata(rawInput, normalized, sld, tld, isValid),
            linguistics = linguistics,
            warnings = warnings
        )
    }

    private fun countSyllables(word: String): Int {
        if (word.isEmpty()) return 0
        var count = 0
        val cleanWord = word.lowercase(Locale.ROOT)
        
        if (VOWELS.contains(cleanWord[0])) {
            count++
        }
        for (i in 1 until cleanWord.length) {
            if (VOWELS.contains(cleanWord[i]) && !VOWELS.contains(cleanWord[i - 1])) {
                count++
            }
        }
        if (cleanWord.endsWith("e") && count > 1) {
            count--
        }
        return if (count == 0) 1 else count
    }

    private fun getVowelConsonantPattern(word: String): String {
        return buildString {
            for (char in word) {
                when {
                    VOWELS.contains(char) -> append('V')
                    CONSONANTS.contains(char) -> append('C')
                    else -> append('?')
                }
            }
        }
    }
}
