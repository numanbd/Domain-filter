package com.example.service

import com.example.service.DomainParser.ParsingResult

object RuleEngine {

    data class ProfileWeights(
        val lengthWeight: Float,
        val linguisticWeight: Float,
        val tldWeight: Float,
        val memorabilityWeight: Float,
        val cleanStructureWeight: Float
    )

    data class ScoringProfile(
        val id: String,
        val name: String,
        val description: String,
        val weights: ProfileWeights,
        val premiumThreshold: Float = 75f
    )

    val PROFILES = listOf(
        ScoringProfile(
            id = "balanced",
            name = "Balanced Portfolio",
            description = "Standard weights for general investment appraisal.",
            weights = ProfileWeights(0.25f, 0.25f, 0.20f, 0.20f, 0.10f)
        ),
        ScoringProfile(
            id = "brandable",
            name = "Brandable Focus",
            description = "Favors smooth linguistics, pronounceability, and memorability.",
            weights = ProfileWeights(0.15f, 0.35f, 0.15f, 0.25f, 0.10f)
        ),
        ScoringProfile(
            id = "short",
            name = "Short Domain Focus",
            description = "Heavily prioritizes ultra-short length structures (L-L-L or L-L-L-L).",
            weights = ProfileWeights(0.45f, 0.15f, 0.15f, 0.15f, 0.10f)
        ),
        ScoringProfile(
            id = "startup",
            name = "Startup & VC Focus",
            description = "Prioritizes modern tech TLDs and brandable memorability profiles.",
            weights = ProfileWeights(0.20f, 0.25f, 0.20f, 0.25f, 0.10f)
        )
    )

    data class ScoreBreakdown(
        val lengthScore: Float,
        val linguisticScore: Float,
        val tldScore: Float,
        val memorabilityScore: Float,
        val cleanStructureScore: Float,
        val totalScore: Float,
        val isPremium: Boolean,
        val profileId: String
    )

    fun score(parsingResult: ParsingResult, profileId: String = "balanced"): ScoreBreakdown {
        val profile = PROFILES.find { it.id == profileId } ?: PROFILES[0]
        val syntax = parsingResult.syntax
        val linguistics = parsingResult.linguistics

        // 1. Length Score (0-100)
        val sldLength = syntax.sld.length
        val lengthScore = when {
            sldLength <= 3 -> 100f
            sldLength == 4 -> 95f
            sldLength == 5 -> 85f
            sldLength == 6 -> 75f
            sldLength == 7 -> 65f
            sldLength == 8 -> 55f
            else -> (50f - (sldLength - 8) * 6f).coerceAtLeast(10f)
        }

        // 2. Linguistic Score (0-100)
        var lingScore = 40f
        if (linguistics.isPronounceable) lingScore += 30f
        
        // Vowel ratio ideal zone is 0.35 to 0.45
        val ratioDeviation = Math.abs(linguistics.vowelRatio - 0.40f)
        val ratioBonus = (20f - ratioDeviation * 100f).coerceIn(0f, 20f)
        lingScore += ratioBonus

        if (linguistics.syllableCount <= 2) lingScore += 10f
        lingScore = lingScore.coerceIn(0f, 100f)

        // 3. TLD Score (0-100)
        val tldScore = when (syntax.tld) {
            "com" -> 100f
            "ai" -> 90f
            "io" -> 85f
            "co" -> 80f
            "net" -> 70f
            "org" -> 65f
            "app", "dev" -> 60f
            "xyz" -> 40f
            else -> 25f
        }

        // 4. Memorability Score (0-100)
        // Radio test is an excellent proxy, higher if short and pronounceable
        var memScore = linguistics.radioTestScore
        if (sldLength <= 5) memScore += 15f
        if (linguistics.isPronounceable) memScore += 10f
        memScore = memScore.coerceIn(0f, 100f)

        // 5. Clean Structure Score (0-100)
        var cleanScore = 100f
        if (linguistics.hasHyphens) cleanScore -= 40f
        if (linguistics.hasNumbers) cleanScore -= 50f
        cleanScore = cleanScore.coerceAtLeast(10f)

        // Calculate weighted aggregate
        val w = profile.weights
        val totalScore = (lengthScore * w.lengthWeight) +
                (lingScore * w.linguisticWeight) +
                (tldScore * w.tldWeight) +
                (memScore * w.memorabilityWeight) +
                (cleanScore * w.cleanStructureWeight)

        // Premium criteria
        val meetsPremiumScore = totalScore >= profile.premiumThreshold
        val isPremium = meetsPremiumScore && 
                !linguistics.hasNumbers && 
                !linguistics.hasHyphens && 
                (syntax.tld == "com" || syntax.tld == "ai" || syntax.tld == "io" || syntax.tld == "co")

        return ScoreBreakdown(
            lengthScore = lengthScore,
            linguisticScore = lingScore,
            tldScore = tldScore,
            memorabilityScore = memScore,
            cleanStructureScore = cleanScore,
            totalScore = totalScore,
            isPremium = isPremium,
            profileId = profile.id
        )
    }
}
